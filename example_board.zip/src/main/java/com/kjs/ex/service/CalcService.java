package com.kjs.ex.service;

import com.kjs.ex.vo.CalcVO;

public interface CalcService {

	public void insert(CalcVO vo);
	
	public void delete(CalcVO vo);
}
