package com.kjs.ex.dao;

import com.kjs.ex.vo.CalcVO;

public interface CalcDAO {
	
	public void insert(CalcVO vo);
	
	public void delete(CalcVO vo);

}
